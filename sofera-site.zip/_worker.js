// Cloudflare Pages "advanced mode" worker for Sofera.
// Serves the app shell on real URLs, adds search-engine tags per page, builds sitemap.xml and robots.txt,
// and serves /config.js from the SUPABASE_URL and SUPABASE_ANON_KEY environment variables.
const SEC={"X-Content-Type-Options":"nosniff","X-Frame-Options":"DENY","Referrer-Policy":"strict-origin-when-cross-origin","Permissions-Policy":"camera=(), microphone=(), geolocation=()","Strict-Transport-Security":"max-age=31536000; includeSubDomains","Content-Security-Policy":"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src https://fonts.gstatic.com; img-src 'self' data: blob: https://*.supabase.co; media-src 'self' blob: https://*.supabase.co; connect-src 'self' https://*.supabase.co; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"};
const HOME_DESC="Sofera — custom-made premium sofas and furniture in Bengaluru. Choose your size, fabric and colour. Enquire on WhatsApp for prices.";
const esc=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
function withHeaders(res,extra){const h=new Headers(res.headers);for(const k in SEC)h.set(k,SEC[k]);for(const k in(extra||{}))h.set(k,extra[k]);return new Response(res.body,{status:res.status,headers:h})}
async function sb(env,path){if(!env.SUPABASE_URL||!env.SUPABASE_ANON_KEY)return null;try{const r=await fetch(env.SUPABASE_URL+path,{headers:{apikey:env.SUPABASE_ANON_KEY}});return r.ok?await r.json():null}catch(e){return null}}
function seo(html,o){
html=html.replace(/<title>[\s\S]*?<\/title>/,"<title>"+esc(o.title)+"</title>");
html=html.replace(/<meta name="description" content="[^"]*">/,'<meta name="description" content="'+esc(o.desc)+'">');
html=html.replace(/<meta property="og:title" content="[^"]*">/,'<meta property="og:title" content="'+esc(o.title)+'">');
html=html.replace(/<meta property="og:description" content="[^"]*">/,'<meta property="og:description" content="'+esc(o.desc)+'">');
let add='<link rel="canonical" href="'+esc(o.canonical)+'"><meta property="og:url" content="'+esc(o.canonical)+'">';
if(o.noindex)add+='<meta name="robots" content="noindex,nofollow">';
if(o.image)add+='<meta property="og:image" content="'+esc(o.image)+'">';
if(o.ld)add+='<script type="application/ld+json">'+JSON.stringify(o.ld).replace(/</g,"\\u003c")+'</script>';
html=html.replace("</head>",add+"</head>");
if(o.noscript)html=html.replace(/<noscript>[\s\S]*?<\/noscript>/,"<noscript>"+o.noscript+"</noscript>");
return html}
async function page(u,p,env){
const r=await env.ASSETS.fetch(new Request(u.origin+"/",{headers:{accept:"text/html"}}));let html=await r.text(),status=200;
const canon=u.origin+(p==="/"?"/":p);
if(p==="/"){html=seo(html,{title:"Sofera — Custom Premium Sofas in Bengaluru",desc:HOME_DESC,canonical:canon})}
else if(p==="/collection"){
const rows=(await sb(env,"/rest/v1/products?select=slug,title&published=eq.true&order=created_at.desc&limit=100"))||[];
html=seo(html,{title:"Collection — Sofera",desc:"Browse custom sofas in leather, velvet and fabric, made to your size and colour in Bengaluru.",canonical:canon,noscript:"<h1>Sofera collection</h1><ul>"+rows.map(x=>'<li><a href="/sofa/'+esc(x.slug)+'">'+esc(x.title)+"</a></li>").join("")+"</ul>"})}
else if(p.indexOf("/sofa/")===0){
let slug="";try{slug=decodeURIComponent(p.slice(6))}catch(e){}
if(!/^[a-z0-9-]{1,80}$/.test(slug)){status=404}else{
const rows=await sb(env,"/rest/v1/products?select=*&published=eq.true&slug=eq."+slug);
if(rows&&rows[0]){const x=rows[0],img=x.image_url&&x.image_url.charAt(0)==="/"?u.origin+x.image_url:x.image_url,d=x.description||"Custom sofa by Sofera, Bengaluru. Enquire on WhatsApp for price and options.";
html=seo(html,{title:x.title+" — Sofera",desc:d,canonical:canon,image:img,ld:{"@context":"https://schema.org","@type":"Product",name:x.title,description:d,image:img,brand:{"@type":"Brand",name:"Sofera"},url:canon},noscript:"<h1>"+esc(x.title)+"</h1><p>"+esc(d)+'</p><p><a href="/collection">All sofas</a> · WhatsApp +91 70989 93786</p>'})}
else if(rows!==null){status=404;html=seo(html,{title:"Not found — Sofera",desc:HOME_DESC,canonical:u.origin+"/",noindex:true})}}}
else if(p==="/admin"){html=seo(html,{title:"Admin — Sofera",desc:"Sofera admin",canonical:canon,noindex:true})}
else{status=404;html=seo(html,{title:"Not found — Sofera",desc:HOME_DESC,canonical:u.origin+"/",noindex:true})}
return withHeaders(new Response(html,{status,headers:{"content-type":"text/html; charset=utf-8","cache-control":"public, max-age=120"}}))}
async function sitemap(u,env){
const rows=(await sb(env,"/rest/v1/products?select=slug,updated_at&published=eq.true"))||[];
const urls=[["/",""],["/collection",""]].concat(rows.map(r=>["/sofa/"+r.slug,r.updated_at||""]));
const xml='<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+urls.map(x=>"<url><loc>"+esc(u.origin+x[0])+"</loc>"+(x[1]?"<lastmod>"+esc(String(x[1]).slice(0,10))+"</lastmod>":"")+"</url>").join("")+"</urlset>";
return withHeaders(new Response(xml,{headers:{"content-type":"application/xml; charset=utf-8","cache-control":"public, max-age=600"}}))}
export default{async fetch(req,env){
const u=new URL(req.url),p=u.pathname.replace(/\/+$/,"")||"/";
if(req.method!=="GET"&&req.method!=="HEAD")return new Response("Method not allowed",{status:405});
if(p==="/config.js")return withHeaders(new Response("window.SOFERA_CFG="+JSON.stringify({url:env.SUPABASE_URL||"",key:env.SUPABASE_ANON_KEY||""})+";",{headers:{"content-type":"application/javascript; charset=utf-8","cache-control":"no-store"}}));
if(p==="/robots.txt")return withHeaders(new Response("User-agent: *\nAllow: /\nDisallow: /admin\nSitemap: "+u.origin+"/sitemap.xml\n",{headers:{"content-type":"text/plain; charset=utf-8"}}));
if(p==="/sitemap.xml")return sitemap(u,env);
if(/\.[a-z0-9]{2,5}$/i.test(p)||p.indexOf("/assets/")===0){const r=await env.ASSETS.fetch(req);const long=/^\/assets\/(frames|video|p)\//.test(p);return withHeaders(r,{"Cache-Control":long?"public, max-age=31536000, immutable":"public, max-age=300"})}
return page(u,p,env)}};
