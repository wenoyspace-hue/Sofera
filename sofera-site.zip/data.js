(function(){var C=window.SOFERA_CFG||{};
function ok(r){if(!r.ok)throw new Error(r.status);return r.json()}
function map(r){return{id:r.id,slug:r.slug,title:r.title,cat:r.category_id,desc:r.description||"",colour:r.colour||"",material:r.material||"",dims:r.dimensions||"",avail:r.availability||"",price:r.price_text||"",ptype:"",img:r.image_url,pub:r.published!==false,fan:!!r.featured}}
function live(){var h={apikey:C.key};return Promise.all([fetch(C.url+"/rest/v1/categories?select=*&order=sort.asc",{headers:h}).then(ok),fetch(C.url+"/rest/v1/products?select=*&published=eq.true&order=created_at.desc",{headers:h}).then(ok)]).then(function(a){return{cats:a[0].map(function(c){return{id:c.id,name:c.name}}),products:a[1].map(map)}})}
window.SOFERA_LOAD=live;
function seed(){return fetch("/assets/seed.json").then(ok)}
window.SOFERA_DATA=(C.url&&C.key?live():Promise.reject()).catch(seed).then(function(d){return fetch("/assets/reels.json").then(ok).then(function(r){d.reels=r;return d},function(){d.reels=[];return d})});
})();
